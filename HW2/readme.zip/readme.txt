g++ StoogeSort.cpp -o StoogeSort
